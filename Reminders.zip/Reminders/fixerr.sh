#!/bin/bash

echo 'Reminders.py error fixer'
echo 'Copyright 2020 Andy Zhang.'

echo 'Fixing errors...'
echo '' > rDat.txt
echo Errors were fixed!

echo Exiting in 5 secs
sleep 5s
exit
